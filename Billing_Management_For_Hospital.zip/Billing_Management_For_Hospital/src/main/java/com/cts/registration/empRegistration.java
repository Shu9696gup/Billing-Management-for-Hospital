package com.cts.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class empRegistration
 */
@WebServlet("/emp-register")
public class empRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String empName= request.getParameter("name");
		String empId = request.getParameter("empId");
		String empEmail= request.getParameter("email");
		String empPassword= request.getParameter("pass");
		String empMobile= request.getParameter("contact");
		String adminCheck = "false";
		
		
		RequestDispatcher dispatcher = null;
		Connection con= null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital?useSSL=false","root","shu123gup");
			PreparedStatement pst = con.prepareStatement("insert into employee(empName,empId,empPassword,empEmail,empMobile,adminCheck) values(?,?,?,?,?,?)");
			pst.setString(1, empName);
			pst.setString(2, empId);
			pst.setString(3, empPassword);
			pst.setString(4, empEmail);
			pst.setString(5, empMobile);
			pst.setString(6, adminCheck);
			
			int rowCount = pst.executeUpdate();
			dispatcher = request.getRequestDispatcher("empRegistration.jsp");
			if(rowCount>0) {
				request.setAttribute("status", "success");
				//dispatcher = request.getRequestDispatcher("login.jsp");
			}else {
				request.setAttribute("status", "failed");
			}
			dispatcher.forward(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try {
				response.sendRedirect("empLogin.jsp");
				con.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
