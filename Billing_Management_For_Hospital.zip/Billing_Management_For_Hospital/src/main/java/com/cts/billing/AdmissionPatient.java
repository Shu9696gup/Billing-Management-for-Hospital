package com.cts.billing;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AdmissionPatient
 */
@WebServlet("/add-patient")
public class AdmissionPatient extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id= request.getParameter("userId");
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		String symptoms = request.getParameter("symptoms");
		String address = request.getParameter("address");
		String date= request.getParameter("date");
		
		
		RequestDispatcher dispatcher = null;
		Connection con= null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital?useSSL=false","root","shu123gup");
			PreparedStatement pst = con.prepareStatement("insert into patient(userId,pName,pAage,pSymptoms,pAddress,pDate) values(?,?,?,?,?,?)");
			pst.setString(1, id);
			pst.setString(2, name);
			pst.setString(3, age);
			pst.setString(4, symptoms);
			pst.setString(5, address);
			pst.setString(6, date);
		
			PrintWriter out = response.getWriter();
			int rowCount = pst.executeUpdate();
		
			if(rowCount>0) {
				
				request.setAttribute("status", "success");
				out.println("Patient details saved");
				//dispatcher = request.getRequestDispatcher("login.jsp");
			}else {
				request.setAttribute("status", "failed");
			}
			dispatcher.forward(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try {
				response.sendRedirect("billgenration.jsp");
				con.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
