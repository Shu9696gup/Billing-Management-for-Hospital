package com.cts.billing;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewBillAdmin
 */
@WebServlet("/patient-bill")
public class ViewBillAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
    

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String pId = request.getParameter("pId");
		String bill= request.getParameter("billtype");
		//System.out.println(bill);
		
		
			
		if(bill.equals("cbill")) {
				try {
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital?useSSL=false","root","shu123gup");
				PreparedStatement pst = con.prepareStatement("select * from cbill where pId=?");
				pst.setString(1, pId);
				ResultSet rs = pst.executeQuery();
				
				out.println("<h3>Consultancy Bill</h3>");
				out.println("<html><body><table border='1'><tr><td>Bill Id</td><td>Bill Date</td> <td>Bill Time</td> <td>Name</td> <td>Symptoms</td> <td>Doctor Name</td> <td>Specialization</td> <td>Amount</td></tr>");
				while(rs.next()) {
					out.println("<tr> <td>"+rs.getString(1)+"</td> <td>"+rs.getString(2)+"</td> <td>"+rs.getString(3)+"</td> <td>"+rs.getString(9)+"</td> <td>"+rs.getString(5)+"</td> <td>"+rs.getString(6)+"</td>	<td>"+rs.getString(7)+"</td> <td>"+rs.getString(8)+"</td> </tr>");
					}
				out.println("</table></body></html><br>");
				}catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}
			
			if(bill.equals("sbill")) {
				System.out.println(bill);
				try {
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital?useSSL=false","root","shu123gup");
				PreparedStatement pst1 = con1.prepareStatement("select * from sbill where pId=?");
				pst1.setString(1, pId);
				ResultSet rs1 = pst1.executeQuery();
				
				out.println("<h3>Service Bill</h3>");
				out.println("<html><body><table border='1'><tr><td>Bill Id</td><td>Bill Date</td> <td>Bill Time</td> <td>Name</td> <td>Symptoms</td> <td>Service</td> <td>Procedure</td> <td>Amount</td></tr>");
				while(rs1.next()) {
					out.println("<tr> <td>"+rs1.getString(1)+"</td> <td>"+rs1.getString(2)+"</td> <td>"+rs1.getString(3)+"</td> <td>"+rs1.getString(5)+"</td> <td>"+rs1.getString(6)+"</td> <td>"+rs1.getString(7)+"</td>	<td>"+rs1.getString(8)+"</td> <td>"+rs1.getString(9)+"</td> </tr>");
					}
				out.println("</table></body></html><br>");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(bill.equals("mbill")) {
				try {
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();

				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital?useSSL=false","root","shu123gup");
				PreparedStatement pst2 = con2.prepareStatement("select * from mbill where pId=?");
				pst2.setString(1, pId);
				ResultSet rs2 = pst2.executeQuery();
				
				out.println("<h3>Pharmacy Bill</h3>");
				out.println("<html><body><table border='1'><tr><td>Bill Id</td><td>Bill Date</td> <td>Bill Time</td> <td>Name</td> <td>Symptoms</td> <td>Medicine</td> <td>Manufacturer</td> <td>Amount</td></tr>");
				while(rs2.next()) {
					out.println("<tr> <td>"+rs2.getString(1)+"</td> <td>"+rs2.getString(2)+"</td> <td>"+rs2.getString(3)+"</td> <td>"+rs2.getString(5)+"</td> <td>"+rs2.getString(6)+"</td> <td>"+rs2.getString(7)+"</td>	<td>"+rs2.getString(8)+"</td> <td>"+rs2.getString(9)+"</td> </tr>");
					}
				out.println("</table></body></html><br>");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(bill.equals("miscbill")) {
				try {
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con3 = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital?useSSL=false","root","shu123gup");
				PreparedStatement pst3 = con3.prepareStatement("select * from miscbill where pId=?");
				pst3.setString(1, pId);
				ResultSet rs3 = pst3.executeQuery();
				System.out.println("shubham");
				out.println("<h3>Miscellaneous Bill</h3>");
				out.println("<html><body><table border='1'><tr><td>Bill Id</td><td>Bill Date</td> <td>Bill Time</td> <td>Name</td> <td>Symptoms</td> <td>Facility</td> <td>Type</td> <td>Amount</td></tr>");
				while(rs3.next()) {
					out.println("<tr> <td>"+rs3.getString(1)+"</td> <td>"+rs3.getString(2)+"</td> <td>"+rs3.getString(3)+"</td> <td>"+rs3.getString(5)+"</td> <td>"+rs3.getString(6)+"</td> <td>"+rs3.getString(7)+"</td>	<td>"+rs3.getString(8)+"</td> <td>"+rs3.getString(9)+"</td> </tr>");
					}
				out.println("</table></body></html><br>");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}		
			
			
			
			
		
		
	}

}
