package com.cts.billing;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PharmacyBill
 */
@WebServlet("/pharmacy-bill")
public class PharmacyBill extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String pId= request.getParameter("pId");
		String date= request.getParameter("date");
		String time= request.getParameter("time");
		String medicine = request.getParameter("medicine");
		String pName="";
		String pSymptoms="";
		String mManu="";
		String mCost="";
		
		Connection con= null;
		Connection con2=null;
		Connection con3=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital?useSSL=false","root","shu123gup");
			PreparedStatement pst = con.prepareStatement("select * from patient where pId=?");
			pst.setString(1, pId);
			ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				 pName= rs.getString(3);
				 pSymptoms = rs.getString(5);
			}
			
			//con.close();
			Class.forName("com.mysql.cj.jdbc.Driver");
			con2= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital?useSSL=false","root","shu123gup");
			PreparedStatement pst2 = con2.prepareStatement("select * from pharmacy where mName=?");
			pst2.setString(1, medicine);
			ResultSet rs2 = pst2.executeQuery();
			if(rs2.next()) {
				 mManu= rs2.getString(3);
				 mCost= rs2.getString(4);
			}
			
			//con2.close();
			Class.forName("com.mysql.cj.jdbc.Driver");
			con3= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital?useSSL=false","root","shu123gup");
			PreparedStatement pst3 = con3.prepareStatement("insert into mbill(bDate,bTime,pId,pName,pSymptoms,mName,mManufacturer,mCost) values(?,?,?,?,?,?,?,?)");
			pst3.setString(1, date);
			pst3.setString(2, time);
			pst3.setString(3, pId);
			pst3.setString(4, pName);
			pst3.setString(5, pSymptoms);
			pst3.setString(6, medicine);
			pst3.setString(7, mManu);
			pst3.setString(8, mCost);
			int count = pst3.executeUpdate();
			if(count>0) {
				response.sendRedirect("billgenration.jsp");
			}else {
				response.sendRedirect("billgenration.jsp");
			}
			
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
