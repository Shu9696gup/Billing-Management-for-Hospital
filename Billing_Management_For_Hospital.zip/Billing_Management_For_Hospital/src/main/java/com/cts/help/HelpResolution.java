package com.cts.help;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelpResolution
 */
@WebServlet("/help-resolution")
public class HelpResolution extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		try {
			response.setContentType("text/html");
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital?useSSL=false","root","shu123gup");
			PreparedStatement pst = con.prepareStatement("select * from help where solution='pending'");
			ResultSet rs = pst.executeQuery();
			PrintWriter out = response.getWriter();
			out.println("<html><body><table border='1'><tr><td>Ticket Id</td><td>Patient Id</td><td>Patient Name</td><td>Section</td><td>Description</td><td>Resolution </td></tr>");
			while(rs.next()) {
				out.println("<tr><td>"+rs.getString(1)+"</td> <td>"+rs.getString(2)+"</td> <td>"+rs.getString(3)+"</td> <td>"+rs.getString(4)+"</td> <td>"+rs.getString(5)+"</td><td> <form method='post' action='submit-resolution'><input type='text' required name='sol' placeHolder='Resolution'/><input type='text' name='tId' placeHolder='Ticket-Id'/> <input type='submit' /></form> </td></tr>  " );
			}
			out.println("</table></body></html>");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
