package com.cts.help;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelpResolutionByAdmin
 */
@WebServlet("/submit-resolution")
public class HelpResolutionByAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String sol = request.getParameter("sol");
		String tId = request.getParameter("tId");
		try {
			response.setContentType("text/html");
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital?useSSL=false","root","shu123gup");
			PreparedStatement pst = con.prepareStatement("update help set solution = ? where ticketId=?");
			pst.setString(1, sol);
			pst.setString(2, tId);
			//ResultSet rs = pst.executeQuery();
			PrintWriter out = response.getWriter();
			int rowCount = pst.executeUpdate();
			
			if(rowCount>0) {
				
				response.sendRedirect("adminHome.jsp");
			}
			else {
				response.sendRedirect("adminHome.jsp");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
	}

}
